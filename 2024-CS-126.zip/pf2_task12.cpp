#include<iostream>
using namespace std;

main()
{
	cout<<"\t                                               "<<endl;
	cout<<"\t    *             *          *                 "<<endl;
	cout<<"\t     *             *          *                "<<endl;
	cout<<"\t      *             *          *               "<<endl;
	cout<<"\t     *             *          *                "<<endl;
	cout<<"\t    *            *           *                 "<<endl;
	cout<<"\t     *            *           *                "<<endl;
	cout<<"\t     *             *           *               "<<endl;
	cout<<"\t**************************************         "<<endl;
	cout<<"\t *                                  *          "<<endl;
	cout<<"\t  *                                *           "<<endl;
	cout<<"\t   *                              *            "<<endl;
	cout<<"\t    *                            *             "<<endl;
	cout<<"\t     ****************************              "<<endl<<endl<<endl;
	cout<<"\t     #WELCOME TO FOODY APPLICATION                  "<<endl<<endl;
}