#include<iostream>
using namespace std;

main()
{

	system("color 03 ");

	cout<<"\t +--^----------,-------,-----,--------^--,      "<<endl;
	cout<<"\t  | ||||||||    '-------'     |           O    "<<endl;
	cout<<"\t  '+--------------------------^-----------|    "<<endl;
	cout<<"\t    ',---------,---------,----------------'      "<<endl;
	cout<<"\t      / XXXXXX /'|       /'                                 "<<endl;
	cout<<"\t     / XXXXXX /  |      /'                                   "<<endl;
	cout<<"\t    / XXXXXX /'-------'                                          "<<endl;
	cout<<"\t   / XXXXXX /                                            "<<endl;
	cout<<"\t  / XXXXXX /                                             "<<endl;
	cout<<"\t (________(                                              "<<endl;
	cout<<"\t  '------'                                      "<<endl<<endl;
	

}