#include<iostream>
using namespace std;

main()
{
system("color 37");
cout <<"     .::---::..     "<<endl;
cout <<"  .---------------. "<<endl;
cout <<" .-----------------."<<endl;
cout <<" ----------------:. "<<endl;
cout <<":-----------::.     "<<endl;
cout <<"-----------:.       "<<endl;
cout <<":------------::.    "<<endl;
cout <<" :---------------:. "<<endl;
cout <<"  .--------------:  "<<endl;
cout <<"   .:-------------:."<<endl;

}