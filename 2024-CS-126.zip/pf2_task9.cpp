#include<iostream>
using namespace std;

main()
{
	cout<<" -------------------------------  "<<endl<<endl<<endl;
	cout<<"       O    ^____^                "<<endl<<endl;

	cout<<"         o  ( OO )\\___________   "<<endl<<endl;

	cout<<"            ( __ )\\        )\\/\\"<<endl;
	cout<<"                                   "<<endl;
	cout<<"                  | | ----W  |     "<<endl;
	cout<<"                  | |        |     "<<endl<<endl;
	cout<<"                  | |      | |     "<<endl;
	cout<<"                  | |      | |      "<<endl;
}